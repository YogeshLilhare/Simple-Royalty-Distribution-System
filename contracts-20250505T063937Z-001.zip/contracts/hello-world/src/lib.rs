#![no_std]
use soroban_sdk::{contract, contractimpl, contracttype, Address, Env, Symbol, Vec, map, Map, log, symbol_short};

// Royalty info per stakeholder
#[contracttype]
#[derive(Clone)]
pub struct Stakeholder {
    pub recipient: Address,
    pub percentage: u32, // expressed in basis points (e.g., 1000 = 10%)
}

#[contracttype]
pub struct RoyaltyData {
    pub stakeholders: Vec<Stakeholder>,
}

#[contracttype]
pub enum RoyaltyKey {
    Royalties(Symbol),
}

#[contract]
pub struct RoyaltyContract;

#[contractimpl]
impl RoyaltyContract {
    // Set stakeholders for a content ID
    pub fn set_royalties(env: Env, content_id: Symbol, stakeholders: Vec<Stakeholder>) {
        let total: u32 = stakeholders.iter().map(|s| s.percentage).sum();
        if total != 10_000 {
            panic!("Total percentage must equal 10000 basis points (100%)");
        }
        env.storage().instance().set(&RoyaltyKey::Royalties(content_id.clone()), &RoyaltyData {
            stakeholders
        });
        log!(&env, "Royalties set for content: {}", content_id);
    }

    // Simulate royalty payout distribution
    pub fn distribute(env: Env, content_id: Symbol, amount: u64) -> Map<Address, u64> {
        let royalty_data: RoyaltyData = env
            .storage()
            .instance()
            .get(&RoyaltyKey::Royalties(content_id.clone()))
            .expect("No royalty data for this content");

        let mut payouts: Map<Address, u64> = map!(&env);

        for s in royalty_data.stakeholders.iter() {
            let payout = amount * s.percentage as u64 / 10_000;
            payouts.set(s.recipient.clone(), payout);
        }

        log!(&env, "Royalty payout simulated for content: {}", content_id);
        payouts
    }
}
